python task4.py sa --outfile="temp" --file="./inst/knap_gen_100.dat" --sol="./inst/knap_gen_100.sol.dat" -t "30 100 5000" -c"0.996 0.998 0.1" -i "60 400 3000"
